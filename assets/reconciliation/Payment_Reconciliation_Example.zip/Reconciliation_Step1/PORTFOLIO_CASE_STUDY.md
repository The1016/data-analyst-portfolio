# Payment Reconciliation and Exception Reporting

**Synthetic portfolio demonstration | Python, pandas and Excel | MD Zawwadul Islam**

## The problem
Two teams may report the same set of payments in different orders, with missing records, duplicate references or conflicting amounts. Comparing only the grand totals does not identify which transactions need attention.

## What I built
I built a Python workflow that compares two synthetic payment files using one transaction reference. It trims surrounding spaces while retaining original identifiers, compares amounts exactly to the paisa, and separates ambiguous or missing references for review.

The output includes a transaction-level comparison, an exceptions list, cleaned copies with original values retained, source row/amount checks and an explanation of the overall difference. A formatted Excel workbook presents the verified baseline result.

## Demonstration results
The two invented sources contain 101 records in total: 50 in A and 51 in B. The workflow identifies:
- 43 exact matched pairs.
- 3 pairs with amount differences.
- 3 records present only in A and 2 present only in B.
- 3 source rows held as ambiguous because a reference repeats in B.
- 1 source row with a missing reference.

The report has 55 rows representing all 101 source records. Twelve report rows require review; paired differences account for two source records each. Source A totals Tk62,750.00 and source B totals Tk64,320.01, producing an A-minus-B difference of -Tk1,570.01. The workflow conserves both source totals and checks that every original source row is represented exactly once on its own side.

## Why this is useful
A reviewer receives a focused list of amount differences, one-sided records and ambiguous entries, with source-row locations for investigation. The workflow identifies discrepancies without changing financial records or guessing uncertain matches.

## Validation and boundaries
I checked the results against independently specified expected answers, manually verified three known amount differences and tested source-row and amount conservation. The demonstration uses invented data and bank names; it is not a bank client engagement. No time-saving, revenue or loss-prevention claim has been measured. Matching dates or bank names, aggregation, fuzzy matching and production system integration are outside this example.

**Portfolio preview:** `screenshots/01_summary.png` and `screenshots/02_exceptions.png`.
**Workbook:** `reports/Reconciliation_Example.xlsx`.
**Code and method:** `01_Reconciliation_Walkthrough.ipynb`.
