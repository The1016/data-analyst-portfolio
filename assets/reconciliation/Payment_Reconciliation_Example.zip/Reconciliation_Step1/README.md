# Complete step 1 — payment reconciliation example

MD Zawwadul Islam · Synthetic portfolio demonstration

All data and bank names are invented. This is not a client engagement.

## Start here
1. Extract this entire folder. Do not run the notebook inside the ZIP.
2. Open `reports/Reconciliation_Example.xlsx` to see the target deliverable.
3. Open `01_Reconciliation_Walkthrough.ipynb` in Jupyter. The working directory should be this folder.
4. If pandas is missing, run `%pip install pandas` in a separate cell and restart the kernel. The analyst's checked run used the versions printed in cell 1.
5. Run the seven code cells in order, reading their explanations and comparing the displayed baseline answers.
6. Open `reports/report.html` to review your generated results, controls, gap explanation and exceptions.
7. Manually check the three amount-difference examples in lesson 6.
8. Read `PORTFOLIO_CASE_STUDY.md`, then use the screenshots and workbook to prepare your portfolio entry.

The executed notebook includes baseline outputs so you can compare your own run. The optional script `python reconciliation_demo.py` executes the same analysis without Jupyter.

## Files you receive
- `data/`: the two original synthetic CSV sources, retained unchanged by the analysis.
- Notebook: explanations, code and executed baseline outputs.
- `expected_results.json`: independently specified expected answers plus baseline file hashes.
- `reports/`: generated CSV tables and standalone HTML report, plus a formatted Excel reference for the supplied baseline.
- `screenshots/`: summary and exception images from the verified baseline workbook.
- `PORTFOLIO_CASE_STUDY.md`: factual, editable copy for your portfolio.

## Expected baseline
Source A has 50 records totalling Tk62,750.00; B has 51 totalling Tk64,320.01.
The overall difference, A minus B, is -Tk1,570.01.
43 pairs match exactly; 3 pairs have amount differences; 3 records occur only in A; 2 only in B; 3 source rows are ambiguous because reference 000048 repeats in B; 1 B source row has no reference.
There are 55 report rows representing all 101 source records. Of those report rows, 12 require review; they represent 15 source records. These are deliberately constructed examples, not observed client performance.

## Rules and limits
One transaction per source row; one intended transaction reference; one sample period; BDT throughout. Trim surrounding spaces only, compare exact integer paisa and flag uncertain/duplicate/missing-reference records. No fuzzy matching, bank-name matching, duplicate removal, netting, aggregation or automatic financial adjustments. A and B are compared symmetrically; neither is treated as an authoritative ledger. Blank/invalid/more-than-two-decimal amounts stop the run instead of becoming zero. Negative and zero amounts are valid signed amounts.
Reference 000047 in A remains Only in A; the blank-reference B row is not guessed to be its counterpart.

## After changing inputs
The notebook or Python script regenerates CSV and HTML outputs; it does NOT refresh the supplied formatted Excel reference or screenshots. New inputs skip only the unchanged-baseline answer checks; source-row and amount-conservation checks still run. Review changed output manually before sharing it.
To build a new Excel delivery, import the new CSV tables using Excel Data > From Text/CSV, set Reference to Text, and put All Results, Exceptions, Controls and Summary into one new `.xlsx` workbook. Keep missing values distinct from zeros. Save screenshots from the new workbook. Do not publish stale baseline files as new results.

## Step 1 completion checklist
- [ ] Your local baseline run finishes without errors.
- [ ] Every expected category/count and the three manually checked amount differences agree.
- [ ] Every original source row appears exactly once on its own side of the result; source totals are conserved.
- [ ] You can explain why duplicate and blank references need review.
- [ ] Case study, workbook and screenshots are ready to share and labelled synthetic.
- [ ] Add the project to your portfolio when you are ready to publish it. The package does not modify the live website.

## Technical references
- pandas merge: https://pandas.pydata.org/docs/reference/api/pandas.merge.html
- Python Decimal: https://docs.python.org/3/library/decimal.html
